/* Copyright 2019 Braden Farmer
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.farmerbb.taskbar.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.farmerbb.taskbar.util.U;

import java.util.Set;

public class KeyboardShortcutActivityLockDevice extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(Intent.ACTION_MAIN.equals(getIntent().getAction())) {
            Intent selector = getIntent().getSelector();
            Set<String> categories = selector != null ? selector.getCategories() : getIntent().getCategories();

            if(categories.contains(Intent.CATEGORY_APP_CALENDAR))
                U.lockDevice(this);
        }

        finish();
    }
}
